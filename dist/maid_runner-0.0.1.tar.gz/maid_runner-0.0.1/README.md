# maid_runner

This package is aimed to provide a seamless thread accumulator,
that can execute accumulated threads in three manners, Queue, Pool and Simultaneous Pool.

Once execution has started, it provides with a handle by which the progress
of the accumulator can be tracked live in terms of percentage of work done.